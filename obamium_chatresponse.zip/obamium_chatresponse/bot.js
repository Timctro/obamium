console.log('Test1');           // Sequential logging for every important dependence.
console.log('Test2');
console.log('Test3');
const config = require('./config.json');
console.log('config.JSON file ready');
console.log('Waiting...');
const Discord = require('discord.js');
const client = new Discord.Client();
console.log('Discord variables on!');
console.log('Online!'); //End of startup logging

client.on("message", function (message) {
  if (message.author.equals(client.user)) return; // Ignores itself
  if (message.channel.type === 'dm') return message.reply("Bro I hate to trip, but DMs ain't the thing. Go play with yo pals in the chat."); // Ignores dms
});
client.on("guildMemberAdd", (member) => {       //New members welcome message
   console.log(`User: ${member.user.username} has joined ${member.guild.name}`);
   var canal = client.channels.get("872077893151371274"); //Replace the X (not the quotes) with the Welcome channel on your server.
   var welcomeMessage = new Discord.RichEmbed()
                        .setTitle("Welcome, "+ member.user.username + "!")
                        .setDescription("Obamium, also known as Obama Pyramid and Obama Prism, refers to a series of memes imagining various chemical substances and geometric figures consisting of and named after the former United States President Barack Obama. I am a Guardian of this Server, and you are kinda sus.")
                        .setColor(0xffffff)
                        .setImage("https://i.kym-cdn.com/photos/images/newsfeed/001/548/016/cc1.gif")
                        .setThumbnail(member.user.displayAvatarURL)
                        .setFooter("Obamium, Inc. 2019 - Present", "https://pbs.twimg.com/media/EJ6ywWvX0AA0Nbo.jpg"); 
     /* This is the embed message from welcome. You can customize this variables.
    .setTitle stands for te title (obviusly)
    .setDescriptions sets the text bellow the title, aka "Description"
    .setColor defines the lateral color of the message. 0x equals # for hex notations. ex: google "white color hex" and you should get the color I used.
    .setThumbnail defines the little pic you got one side of your message. You can replace my content (the profile pic of the new member) with a url, ex: ("https://discord.com/assets/2c21aeda16de354ba5334551a883b481.png"), to set you fav pic as welcome thumbnail.
    .setImage manages the same way .setThumbnail, but for a bigger pic.
    .setFooter puts text in the bottom of the embed message. Before the "," you put text, and after, a pic.
    No field is mandatory.

     */
   canal.send(welcomeMessage);
});

client.on("message", function (message) {
if (message.content === 'hello') {      //The bot will react to "hello" with an emoji. Unicode emojis are easier to add, but not mandatory.
	message.react("😎");}
});
client.on("message", function (message) {
if (message.content === 'good bye') {
	message.react("😽");}
});
client.on("message", function (message) {
if (message.content === "on a mote of dust, suspended in a sunbeam") {
	message.react("⭐");
	message.react("🌌");
	message.react("☀");
}});
client.on('message', message => {
  // If the message is "ping"
  if (message.content === 'ping') {
    // Send "pong" to the same channel
    message.channel.send('pong');
  }
});
client.on('message', message => {
  // If the message is "ping"
  if (message.content === 'ching') {
    // Send "pong" to the same channel
    message.channel.send('chong');
  }
});
client.on('message', message => {
  // If the message is "what is my avatar"
  if (message.content === 'what is my avatar') {
    // Send the user's avatar URL
    message.reply(message.author.displayAvatarURL());
  }
});
client.on('message', message => {
  // Ignore messages that aren't from a guild
  if (!message.guild) return;

  // If the message content starts with "!kick"
  if (message.content.startsWith('69420kick')) {
    // Assuming we mention someone in the message, this will return the user
    // Read more about mentions over at https://discord.js.org/#/docs/main/master/class/MessageMentions
    const user = message.mentions.users.first();
    // If we have a user mentioned
    if (user) {
      // Now we get the member from the user
      const member = message.guild.member(user);
      // If the member is in the guild
      if (member) {
        /**
         * Kick the member
         * Make sure you run this on a member, not a user!
         * There are big differences between a user and a member
         */
        member
          .kick('Optional reason that will display in the audit logs')
          .then(() => {
            // We let the message author know we were able to kick the person
            message.reply(`Successfully kicked ${user.tag}!`);
            message.react("😎");
          })
          .catch(err => {
            // An error happened
            // This is generally due to the bot not being able to kick the member,
            // either due to missing permissions or role hierarchy
            message.reply('I was unable to kick the member');
            // Log the error
            console.error(err);
          });
      } else {
        // The mentioned user isn't in this guild
        message.reply("That user isn't in this guild!");
      }
      // Otherwise, if no user was mentioned
    } else {
      message.reply("You didn't mention the user to kick!");
    }
  }
});
const botStateArray = [
    "Discord", 
    "with your mom",
    "with my about me", 
    "with George W. Bush", 
    "with my non-existant friend", 
    "with bit.ly/bush420", 
    "with Obama", 
    "with Trump",
    "with Biden",
    "with Requiem",
    "​x3 nuzzles, pounces on you",
    "with your heart. UwU",
    "with bit.ly/dscplus"
    ]; // this array contains the former "activity" info of the bot. As it starts, by default, as "playing (your state)", I usually use this word as part of the state message. Ex: Playing the piano; playing chess!, etc.

client.on('ready', () => {
    setInterval(() => {
        const index = Math.floor(Math.random() * (botStateArray.length - 1) + 1); // Generates a number between 1 and the botStateArray length.
        client.user.setActivity(botStateArray[index]); // defines bot's activity as a product between the random number and the array itself
    }, 10000); // time between state changes in miliseconds.
});

//  COMMAND SECTION
client.on("message", message => {
  if (message.author.bot) return; // Don't receive orders from other bots. Important good practice on Discordjs
  if (message.channel.type === 'dm') return; // don't receive commands by dm's. 
    if (!message.content.startsWith(config.prefix)){// Does the command start with the prefix declared in config.JSON?

    }else{//user IS typing a command
    //splits input to commands
      let command = message.content.split(' ')[0];
      command = command.slice(config.prefix.length);  
      try {
        let commandFile = require(`./commands/${command}.js`);
        commandFile.run(client, message, Discord);
      } catch (err) {
        console.log(err);
        client.users.get(config.ownerID).send(`${err}`); //Dm's you the error info. You can delete this if you want, but is always useful have an error log.
        return;
      }
    }
  }
);
client.login(config.token); //discord token allows the bot to connect Discord API and intereact with the platform. NEVER PUBLISH OR SHARE IT. You can always enter you discord dev account and reset the token.