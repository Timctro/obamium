exports.run = (client, message, Discord) => {
    message.channel.send("Hey! Have a nice day :3");
}